package com.optimizex.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Background = Color(0xFF050609)
private val Surface = Color(0xFF10141D)
private val Surface2 = Color(0xFF171E2A)
private val Cyan = Color(0xFF00E5FF)
private val ElectricBlue = Color(0xFF2A6BFF)
private val Violet = Color(0xFF9C6CFF)
private val TextMuted = Color(0xFF93A0B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OptimizeXTheme { OptimizeApp(this) } }
    }
}

@Composable
private fun OptimizeXTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(background = Background, surface = Surface, primary = Cyan), content = content)
}

@Composable
private fun OptimizeApp(activity: Activity) {
    var tab by remember { mutableIntStateOf(0) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var overlayEnabled by remember { mutableStateOf(Settings.canDrawOverlays(activity)) }
    val scroll = rememberScrollState()

    Column(Modifier.fillMaxSize().background(Background)) {
        Header()
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Início", "Ferramentas", "Ajustes").forEachIndexed { index, label ->
                FilterChip(selected = tab == index, onClick = { tab = index }, label = { Text(label, fontSize = 12.sp) })
            }
        }
        Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (tab) {
                0 -> HomeTab(activity, refreshKey, overlayEnabled, { overlayEnabled = it }, { refreshKey++ })
                1 -> ToolsTab(activity)
                else -> SettingsTab(activity, overlayEnabled) { overlayEnabled = it }
            }
            Text("Optimize X usa somente APIs públicas do Android. Nenhum recurso promete FPS artificial ou encerra processos protegidos.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF081421), Background))).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(com.optimizex.app.R.drawable.logo_optimize_x), "Logo Optimize X", Modifier.size(58.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text("OPTIMIZE X", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("CONTROL CENTER", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        Text("v1.1", color = TextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun HomeTab(activity: Activity, refreshKey: Int, overlayEnabled: Boolean, setOverlay: (Boolean) -> Unit, refresh: () -> Unit) {
    val memory = remember(refreshKey) { memoryInfo(activity) }
    val battery = remember(refreshKey) { batteryInfo(activity) }
    val storage = remember(refreshKey) { storageInfo() }
    val cpu = remember { Runtime.getRuntime().availableProcessors() }
    Text("Seu centro de performance", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Text("Leitura em tempo real do que o Android permite acessar.", color = TextMuted, fontSize = 12.sp)
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("STATUS DO DISPOSITIVO", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("ONLINE", color = Color(0xFF63F59A), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            Text("${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Android ${android.os.Build.VERSION.RELEASE}  •  ${android.os.Build.VERSION.SDK_INT}  •  $cpu núcleos", color = TextMuted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("RAM", "${memory.usedMb} MB", "de ${memory.totalMb} MB", Cyan, Modifier.weight(1f)); StatCard("BATERIA", "${battery.percent}%", battery.status, Violet, Modifier.weight(1f)); StatCard("DADOS", storage.used, storage.total, ElectricBlue, Modifier.weight(1f)) }
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("MODO GAME SPACE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Concentre os controles em uma bolha flutuante e abra atalhos sem sair do jogo.", color = TextMuted, fontSize = 12.sp)
            Button(onClick = { if (!Settings.canDrawOverlays(activity)) { activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))) } else { ContextCompat.startForegroundService(activity, Intent(activity, FloatingMenuService::class.java)); setOverlay(true) } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan), shape = RoundedCornerShape(14.dp)) { Text(if (overlayEnabled) "Abrir menu flutuante" else "Autorizar menu flutuante", color = Color.Black, fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Atualizar leituras", color = Color.White) }
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("RECOMENDAÇÃO RÁPIDA", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text("Para jogar melhor de verdade", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("Feche apps pesados manualmente, mantenha espaço livre e use o modo de economia apenas quando a bateria estiver baixa. O Android controla processos protegidos.", color = TextMuted, fontSize = 12.sp) } }
}

@Composable
private fun ToolsTab(activity: Activity) {
    Text("Ferramentas avançadas", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Text("Atalhos reais para preparar o aparelho antes da sessão.", color = TextMuted, fontSize = 12.sp)
    ToolButton("Modo concentração", "Abrir acesso ao Não Perturbe", { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
    ToolButton("Bateria e energia", "Ver economia, consumo e otimização", { activity.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) })
    ToolButton("Armazenamento", "Liberar espaço pelas configurações do sistema", { activity.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) })
    ToolButton("Tela e brilho", "Ajustar brilho, taxa e tempo de tela", { activity.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) })
    ToolButton("Detalhes do Optimize X", "Permissões, bateria e armazenamento do app", { activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))) })
}

@Composable
private fun SettingsTab(activity: Activity, overlayEnabled: Boolean, setOverlay: (Boolean) -> Unit) {
    var bubbleSize by remember { mutableFloatStateOf(64f) }
    var opacity by remember { mutableFloatStateOf(0.92f) }
    var autoStart by remember { mutableStateOf(false) }
    Text("Personalização", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Text("Deixe o painel com a sua cara.", color = TextMuted, fontSize = 12.sp)
    SettingSwitch("Menu flutuante", "Permitir a bolha sobre outros apps", overlayEnabled) { if (!Settings.canDrawOverlays(activity)) activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))) else { setOverlay(it); if (!it) activity.stopService(Intent(activity, FloatingMenuService::class.java)) } }
    SettingSwitch("Iniciar junto com a sessão", "Manter a preferência para o próximo uso", autoStart) { autoStart = it }
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Tamanho da bolha: ${bubbleSize.toInt()} dp", color = Color.White, fontWeight = FontWeight.Bold); Slider(value = bubbleSize, onValueChange = { bubbleSize = it }, valueRange = 48f..96f); Text("Transparência: ${(opacity * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold); Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 0.35f..1f) } }
    ToolButton("Permissões do sistema", "Revisar permissões concedidas ao app", { activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))) })
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = TextMuted, fontSize = 11.sp) }; Switch(checked = checked, onCheckedChange = onChecked) } } }

@Composable
private fun ToolButton(title: String, subtitle: String, onClick: () -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = TextMuted, fontSize = 11.sp) }; OutlinedButton(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text("Abrir", color = Cyan) } } } }

@Composable
private fun StatCard(label: String, value: String, detail: String, color: Color, modifier: Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(10.dp)) { Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold); Text(detail, color = TextMuted, fontSize = 9.sp) } } }

private data class Memory(val usedMb: Int, val totalMb: Int)
private data class Battery(val percent: Int, val status: String)
private data class Storage(val used: String, val total: String)
private fun memoryInfo(context: Context): Memory { val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager; val info = ActivityManager.MemoryInfo(); manager.getMemoryInfo(info); return Memory(((info.totalMem - info.availMem) / 1048576L).toInt(), (info.totalMem / 1048576L).toInt()) }
private fun batteryInfo(context: Context): Battery { val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager; val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100); val status = if (manager.isCharging) "carregando" else "uso normal"; return Battery(level, status) }
private fun storageInfo(): Storage {
    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.totalBytes
    val free = stat.availableBytes
    val usedText = String.format(Locale.getDefault(), "%.1f GB", (total - free) / 1_073_741_824.0)
    val totalText = String.format(Locale.getDefault(), "%.1f GB", total / 1_073_741_824.0)
    return Storage(usedText, totalText)
}
