package com.optimizex.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingMenuService : Service() {
    private lateinit var window: WindowManager
    private lateinit var bubble: TextView
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0

    override fun onCreate() {
        super.onCreate()
        startForeground(7, notification())
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        createBubble()
    }

    private fun createBubble() {
        bubble = TextView(this).apply {
            text = "X"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(0, 92, 155), 18f)
            elevation = 14f
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = bubbleParams.x; startY = bubbleParams.y; true }
                    MotionEvent.ACTION_MOVE -> { bubbleParams.x = startX + (event.rawX - downX).toInt(); bubbleParams.y = startY + (event.rawY - downY).toInt(); window.updateViewLayout(view, bubbleParams); true }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX - downX) < 12 && kotlin.math.abs(event.rawY - downY) < 12) togglePanel(); true }
                    else -> true
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        bubbleParams = WindowManager.LayoutParams(68, 68, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 300 }
        window.addView(bubble, bubbleParams)
    }

    private fun togglePanel() {
        if (panel != null) { panel?.let { window.removeView(it) }; panel = null; return }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); background = rounded(Color.rgb(12, 18, 29), 28f); elevation = 20f }
        val title = TextView(this).apply { text = "OPTIMIZE X  •  GAME SPACE"; textSize = 16f; setTextColor(Color.rgb(0, 229, 255)); setPadding(0, 0, 0, 12) }
        root.addView(title)
        addAction(root, "Monitorar RAM", "Atualizar leitura do dispositivo") { toast("Monitoramento ativo") }
        addAction(root, "Bateria", "Abrir controles de energia") { open(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        addAction(root, "Foco", "Abrir acesso ao Não Perturbe") { open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
        addAction(root, "Armazenamento", "Ver espaço e limpeza do sistema") { open(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        addAction(root, "Brilho e tela", "Ajustar brilho e taxa de atualização") { open(Settings.ACTION_DISPLAY_SETTINGS) }
        val close = Button(this).apply { text = "MINIMIZAR"; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { panel?.let { window.removeView(it) }; panel = null } }
        root.addView(close, LinearLayout.LayoutParams(-1, 50))
        panel = root
        panelParams = WindowManager.LayoutParams(310, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 150 }
        window.addView(root, panelParams)
    }

    private fun addAction(root: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val button = Button(this).apply { text = "$title\n$subtitle"; textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); gravity = Gravity.START or Gravity.CENTER_VERTICAL; setOnClickListener { action() } }
        root.addView(button, LinearLayout.LayoutParams(-1, 64))
    }

    private fun open(action: String) { try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { toast("Atalho indisponível neste aparelho") } }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun notification(): Notification {
        val channel = "optimizex-floating"
        if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel, "Optimize X", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, channel).setContentTitle("Optimize X ativo").setContentText("Menu flutuante pronto para sua sessão").setSmallIcon(android.R.drawable.ic_menu_manage).build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { panel?.let { window.removeView(it) }; if (::bubble.isInitialized) window.removeView(bubble); super.onDestroy() }
}
