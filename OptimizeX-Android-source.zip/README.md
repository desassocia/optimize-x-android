# Optimize X — Android Gaming Optimizer

Primeira versão funcional do aplicativo Android Optimize X, com interface gamer em Jetpack Compose, painel de informações do dispositivo e serviço de menu flutuante usando `SYSTEM_ALERT_WINDOW`.

## O que já funciona

- Dashboard com modelo do aparelho, versão Android e memória RAM.
- Monitoramento básico de memória através de APIs públicas do Android.
- Solicitação da permissão de sobreposição.
- Serviço em primeiro plano e bolha flutuante sobre outros aplicativos.
- Interface escura com azul neon e Material 3.
- Código sem promessas artificiais de aumento de FPS ou encerramento indevido de processos.

## Compilar

```bash
./gradlew assembleDebug
```

O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no aparelho

Transfira o APK para o Android, permita a instalação de fontes desconhecidas quando solicitado e abra o app. Para usar a bolha, permita **Exibir sobre outros apps** no Android.

## Limitações desta primeira versão

A disponibilidade de temperatura, FPS e processos depende das APIs e permissões do aparelho. O Android não permite que um app comum encerre processos protegidos nem garante aumento artificial de desempenho.
