# Optimize X keeps default Android rules.
