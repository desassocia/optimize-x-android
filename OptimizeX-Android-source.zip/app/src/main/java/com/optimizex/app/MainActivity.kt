package com.optimizex.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF05070D); private val Panel = Color(0xFF101722); private val Cyan = Color(0xFF00D9FF); private val Purple = Color(0xFF7C4DFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { OptimizeTheme { Dashboard(this) } } }
}

@Composable fun OptimizeTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan), content = content) }

@Composable fun Dashboard(activity: Activity) {
    var monitoring by remember { mutableStateOf(false) }
    val mem = remember { activity.getSystemService(Activity.ACTIVITY_SERVICE) as android.app.ActivityManager }
    val info = remember { android.app.ActivityManager.MemoryInfo() }
    mem.getMemoryInfo(info)
    val used = ((info.totalMem - info.availMem) / (1024*1024)).toInt(); val total = (info.totalMem / (1024*1024)).toInt()
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("OPTIMIZE X", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Black); Text("ANDROID GAMING OPTIMIZER", color = Color.LightGray, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Painel do dispositivo", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Stat("Modelo", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL); Stat("Android", android.os.Build.VERSION.RELEASE); Stat("Memória", "$used MB usados de $total MB") } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { Metric("RAM", "$used MB", Cyan, Modifier.weight(1f)); Metric("Bateria", "Monitorar", Purple, Modifier.weight(1f)) }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Ferramentas gamer", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Otimização baseada em APIs públicas do Android. Sem promessas artificiais de FPS.", color = Color.LightGray, fontSize = 12.sp); Button(onClick = { monitoring = !monitoring }, colors = ButtonDefaults.buttonColors(containerColor = if (monitoring) Purple else Cyan), modifier = Modifier.fillMaxWidth()) { Text(if (monitoring) "Monitoramento ativo" else "Iniciar monitoramento", color = Color.Black, fontWeight = FontWeight.Bold) }; Button(onClick = { if (!Settings.canDrawOverlays(activity)) activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))) else ContextCompat.startForegroundService(activity, Intent(activity, FloatingMenuService::class.java)) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202B3A)), modifier = Modifier.fillMaxWidth()) { Text("Abrir menu flutuante", color = Color.White) } } }
        Text("Recursos reais: memória disponível, informações do dispositivo e acesso às configurações do sistema.", color = Color.Gray, fontSize = 11.sp)
    }
}
@Composable fun Stat(label:String, value:String) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color=Color.Gray); Text(value, color=Color.White, fontWeight=FontWeight.SemiBold) } }
@Composable fun Metric(label:String, value:String, color:Color, modifier: Modifier) { Card(modifier, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(label, color=Color.Gray); Text(value, color=color, fontWeight=FontWeight.Bold, fontSize=17.sp) } } }
