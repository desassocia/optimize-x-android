package com.optimizex.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingMenuService : Service() {
    private var window: WindowManager? = null; private var bubble: TextView? = null
    override fun onCreate() { super.onCreate(); startForeground(7, notification()); window = getSystemService(WINDOW_SERVICE) as WindowManager; bubble = TextView(this).apply { text = "X"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(0,140,190)); setOnClickListener { Toast.makeText(context, "Optimize X: menu gamer ativo", Toast.LENGTH_SHORT).show() } }; val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE; val p = WindowManager.LayoutParams(64,64,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; y=0 }; window?.addView(bubble,p) }
    private fun notification(): Notification { val channel="optimizex"; if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel,"Optimize X",NotificationManager.IMPORTANCE_LOW)); return Notification.Builder(this,channel).setContentTitle("Optimize X").setContentText("Menu flutuante ativo").setSmallIcon(android.R.drawable.ic_menu_manage).build() }
    override fun onBind(intent: Intent?)=null
    override fun onDestroy(){ bubble?.let{window?.removeView(it)}; super.onDestroy() }
}
